package com.example.the6th.tablayout;

import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;

import com.example.the6th.R;
import com.google.android.material.tabs.TabLayout;


public class tabLayOutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_lay_out);
        TabLayout tabLayout = findViewById(R.id.tb_layout);
        for (int i = 1; i <= 4; i++) {
            tabLayout.addTab(tabLayout.newTab().setText("第" + i + "个"));
        }
    }
}



