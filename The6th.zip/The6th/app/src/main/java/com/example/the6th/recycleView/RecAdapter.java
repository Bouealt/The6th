package com.example.the6th.recycleView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.example.the6th.R;

import java.util.*;

public class RecAdapter extends RecyclerView.Adapter< RecAdapter.ViewHolder> {
    private ArrayList aDataList;
    static class ViewHolder extends RecycleView.ViewHolder{

        public ViewHolder(View VIEW){
            super(view);
        }
    }
    public RecAdapter(ArrayList list){
        aDataList = list;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent,int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout. ,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }
    @Override
    public void onBindViewHolder(ViewHolder holder, int position){

    }
    @Override
    public int getItemCount() {
        if (aDataList != null) {
            return aDataList.size();
        } else {
            return 0;
        }
    }

}
